<?php
/**
 * Its pos order model
 *
 * @since: 21/09/2021
 * @author: Sarwar Hasan
 * @version 1.0.0
 * @package VitePos\Libs
 */

namespace VitePos\Libs;

/**
 * Class Vitepos_WC_Order
 *
 * @package VitePos\Libs
 */
class Vitepos_WC_Order extends \WC_Order {


}