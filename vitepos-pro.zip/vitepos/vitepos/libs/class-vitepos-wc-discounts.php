<?php
/**
 * Its pos order model
 *
 * @since: 21/09/2021
 * @author: Sarwar Hasan
 * @version 1.0.0
 * @package VitePos\Libs
 */

namespace vitepos\vitepos\libs;

/**
 * Class Vitepos_WC_Order
 *
 * @package VitePos\Libs
 */
class Vitepos_WC_discounts extends \WC_Discounts {

	function add_discounts($code){
		
	}

}